﻿using UnityEngine.Events;

namespace ScriptableObjectArchitecture
{
    [System.Serializable]
    public sealed class FloatUnityEvent : UnityEvent<float>
    {
    } 
}