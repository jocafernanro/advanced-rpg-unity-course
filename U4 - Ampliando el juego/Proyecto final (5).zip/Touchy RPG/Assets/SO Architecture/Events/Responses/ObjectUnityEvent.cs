﻿using UnityEngine;
using UnityEngine.Events;

namespace ScriptableObjectArchitecture
{
    [System.Serializable]
    public class ObjectUnityEvent : UnityEvent<Object>
    {
    } 
}