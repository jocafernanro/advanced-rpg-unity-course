﻿using UnityEngine.Events;

namespace ScriptableObjectArchitecture
{
    [System.Serializable]
    public sealed class SByteUnityEvent : UnityEvent<sbyte>
    {
    } 
}