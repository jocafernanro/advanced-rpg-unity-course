﻿using UnityEngine.Events;

namespace ScriptableObjectArchitecture
{
    [System.Serializable]
    public sealed class UIntUnityEvent : UnityEvent<uint>
    {
    } 
}