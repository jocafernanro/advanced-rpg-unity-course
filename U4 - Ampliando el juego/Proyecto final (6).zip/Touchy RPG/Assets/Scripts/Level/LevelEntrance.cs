using UnityEngine;

public class LevelEntrance : MonoBehaviour
{
    public LevelEntranceSO entrance;
}
