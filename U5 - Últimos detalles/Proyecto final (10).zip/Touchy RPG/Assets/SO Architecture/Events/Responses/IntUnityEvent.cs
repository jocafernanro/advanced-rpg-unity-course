﻿using UnityEngine.Events;

namespace ScriptableObjectArchitecture
{
    [System.Serializable]
    public sealed class IntUnityEvent : UnityEvent<int>
    {
    } 
}